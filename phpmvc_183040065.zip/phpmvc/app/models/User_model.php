<?php

class User_model{
    private $nama = 'Aulia';

    public function getUser(){
        return $this->nama;
    }

}