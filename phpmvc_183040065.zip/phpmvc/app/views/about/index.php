<div class="container">
    <h1 class = "mt-4">About Me</h1>
    <img src="<?= BASEURL; ?>/img/home alone2.jpg" alt="Home Alone" width="300" class="rounded-circle shadow" >
    <p class="mt-4">Halo, nama saya <?= $data['nama']; ?>, umur saya <?= $data['umur']; ?> tahun, saya adalah seorang <?= $data['pekerjaan']; ?></p>

</div>